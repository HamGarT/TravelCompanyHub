package com.hamgar.travel_company_hub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TravelCompanyHubApplicationTests {

	@Test
	void contextLoads() {
	}

}
