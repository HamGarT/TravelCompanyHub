package com.hamgar.travel_company_hub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TravelCompanyHubApplication {

	public static void main(String[] args) {
		SpringApplication.run(TravelCompanyHubApplication.class, args);
	}

}
